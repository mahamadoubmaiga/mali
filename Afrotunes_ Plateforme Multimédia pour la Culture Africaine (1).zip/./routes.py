from flask import render_template, session, redirect, url_for, make_response, request
from functools import wraps
from app_init import app
from translations import translations
from models.music import Artist, Album, Track
from models.video import Video

def with_sidebar(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        return render_template(f.__name__.replace('_route', '.html'), with_sidebar=True)
    return decorated_function

@app.route("/")
def landing_route():
    lang = session.get('lang', 'en')
    return render_template("landing.html", with_sidebar=False, translations=translations[lang])

@app.route("/change-language/<lang>")
def change_language(lang):
    if lang in translations:
        session['lang'] = lang
    return redirect(request.referrer or url_for('landing_route'))

@app.route("/profile")
def profile_route():
    return render_template("profile.html", with_sidebar=True)

@app.route("/music")
def music_route():
    artists = Artist.query.all()
    return render_template("music.html", with_sidebar=True, artists=artists)

@app.route("/videos")
def videos_route():
    videos = Video.query.all()
    return render_template("videos.html", with_sidebar=True, videos=videos)

@app.route("/logout", methods=['POST'])
def logout_route():
    session.clear()
    return redirect(url_for('landing_route'))